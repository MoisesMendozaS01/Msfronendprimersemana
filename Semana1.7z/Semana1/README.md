# **Practicas de Intro a Frontend**

Practicas de la primer semana.

Tendrán el siguiente caso y a raiz de eso sacar los puntos mencionados abajo.

Caso: Abogabot

- **Practicas**
	- Toma de requerimientos
    - Crea tu buyer persona
	- Publico objetivo
	- Crea tu primer Wireframe UX
	- Ahora el UI

---
---
## **Toma de requerimientos**
---
### Datos proporcionados
- Despacho de abogados que quiere automatizar las demandas de sus clientes, esto a través de una pagina web llenando un formulario.
- Al momento de llenar el formulario se manda al proceso de pago para finalizar la transacción
-	Para dar seguimiento a su demanda, el cliente crea una cuenta en la plataforma y vera el seguimiento de cada una de las actualizaciones del proceso legal.
-	El administrador del sitio recibe la notificación de una nueva de manda y con los datos llenados del formulario se crea automáticamente el documento legal en formato Word para empezar el proceso.
-	El administrador recibe el pago y debe de ser capaz de verlo en una dashboard para ver la cantidad de ingresos recibidos
-	El administrador actualiza el proceso de la demanda y agrega comentarios en cada paso del proceso
-	Al usuario le llegan correos de notificación para saber el avance de su proceso
-	La página debe de ser responsive para poderla ver desde el celular
-	La preferencia de colores del cliente es azul marino y blanco, pero acepta propuestas.


### Requerimientos funcionales

- Perfil: Permitirá al usuario crear y acceder a un perfil de acceso a la aplicación.

	- Posibilidad de crear perfil a través de correo o enlazandola a su red social preferida.
	- Disponibilidad de acceso continuo y permiso para modificar los datos.

- Nueva demanda: Generar nueva demanda
	- Un boton que permite al usuario acceder a un formulario para generar una demanda legal.
	- De igual manera el administrador recibe los datos en un documento legal en formato word.
- Sistema de pago: Pago de tramite
	- Una vez enviado su formulario se genera su número o de redirige al sistema de pago que más le convenga.
- Actualización de demanda: Permite al administrador actualizar y subir nuevos datos.
	- La pagina permite al administrador modificar los archivos de los estados legales, asi como agregar comentarios para el demandante.

### Requerimientos no funcionales

- Baner con enlaces y menus: visible para permitir al usuario navegar entre las dierentes herramientas.
	- Demandas: permitira al usuario las diferentes demandas realizadas.
	- Notificaciones: widget con forma de campana para avisar al cliente de posibles actualizaciones.
	- Perfil: este lo enviara a sus datos personales.
	- Servicios: este desplegara los diferentes servicios que brinda la empresa que no dependan de la creacion y seguimiento de demandas.
	- Historial: permite al usuario visualizar los pagos que ha realizado
	- Ayuda: Describe las funcionalidades del servicio y su modo de operación.
	- Dashboard: se desplegaran direfentes gráficos que mostraran el progreso de las procesos judiciales, procesos de cobro, asi como visualizar si las personas continuan con el seguimiento de sus casos.
- Pantone para el sitio: El color principal para el sitio es el azul marino y blanco.
- Slider en página principal: Mostrara informacion relevante.
	- Anuncio presentacion del servicio de "Abogabot".
	- Anuncio ventajas de su uso.
	- Anuncio que redirecciona a la creacion de perfil
	- Anuncio a la red social principal del despacho de abogados.
- Version movil: permitira visualizar la informacion en dispositivos moviles.

### Estudio de viabilidad
- Alcance

	La plataformasera será de úso continuo, esto para darle una mejor experiencia al usuario, en cuanto a una menor perdida de tiempo en tramites y permitiendo citas mas consisas.
	Así como una mejor administración de sus datos, como tambien una mejor visualización de los pasos en su proceso legal.
- Valoración de la situación actual

	Actualmente debido a situaciones como la pandemia global nos a obligado a generar nuevas formas de relacionarnos que permitan mantener la sana distancia, por ello se agilizaran los procesos de envio y actualización de información por medio del internet, al cual la mayoria de los clientes si tienen acceso.
- Definir los requisitos del sistema

	Requerimos de de un servidor para alogar el sitio y el correo del mismo, derechos de dominio asi como memoria para almacenar toda la información pertienente.
	Por lo que se contratara un servicio de Hosting de manera que sea economico y escalable en caso de necesitar mayor alcance.

### Obtención y analisis de requerimientos

	Para este caso el ciente se entrevistó para obtener los datos pertienentes al formulario, así como el contrato final al cual se le ingresarán los datos de manera automática.

### Validación de requerimientos.
	
	Para ello aun es necesario que el cliente analice los datos sintetizados por nosotros, asi como el Hosting que mas le convenga.
### Restricciones de proyecto.

	Tecnológias:
	
	FrontEnd: HTML,CSS, JAVASCRIPT
	
	BackEnd: Java
---
---
## **Crear tu buyer de persona**
---

<img src="../images/buyerpersona.png" alt="Buyer Persona" height="350">



 Documento buyer de persona --> [Buyer](./buyer.docx)

----
---
## **Publico objetivo**
---
<img src="../images/p_onj.png" alt="Publico objetivo" height="350">


----
---

## **Wireframe**
---
<img src="../images/wf_webuser.png" alt="user" height="350">

<img src="../images/wf_phoneuser.png" alt="phone" height="350">

<img src="../wf_admin.png" alt="admin" height="350">

----
---

## **UI**
---
<img src="../images/UI.png" alt="ui" height="350">

***¡Vámonos hasta el espacio y más allá Explorers!***
